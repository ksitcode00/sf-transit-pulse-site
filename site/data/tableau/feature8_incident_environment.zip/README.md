# Feature 8 / 历史事件背景

https://data.sf.gov/d/wg3w-h783
2025-09-20 – 2026-09-19

Count distinct incident_id. One report can have multiple categories and overlap multiple stops. Category and stop totals cannot be added. Match incidents and stop_location_matches by location_index; relate categories by incident_id.
事故编号用 COUNTD(incident_id)。一份报告可有多种类别、匹配多个站点，类别与站点数量不能直接相加。事件与站点匹配表用 location_index 关联，类别用 incident_id 关联。

Locations are anonymous nearby intersections, not exact addresses. Day is 06:00–17:59 SF local clock; night is 18:00–05:59. Partial months cannot be compared directly with full months. Report history is not a personal risk prediction.
位置为匿名化附近路口，并非精确地址；白天为旧金山当地06:00–17:59，夜间为18:00–05:59。不完整月份不能直接与完整月份比较。历史报告不预测个人风险。
