# Feature 7 Traffic Safety History / 交通事故历史

Source / 来源: https://data.sf.gov/d/ubvf-ztfx
Pulled / 抓取: 2026-09-18T09:04:11.602066+00:00
Coverage / 覆盖: 2022-01-01 to 2026-07-31

Relate the two CSVs by crash_id. Use COUNTD(crash_id), not row counts after joining. Filter distance_m <= 100 or <= 200.
两张表按 crash_id 建立关系。事故数使用 COUNTD(crash_id)，不要直接数 join 后的行。距离筛选 <=100 或 <=200 米。

Only reported injury/fatal crashes. Current GTFS alignments, not historic geometry. Counts are spatial context, not Muni involvement or individual risk. Latest year may be partial.
仅已报告伤亡事故。使用当前 GTFS 走向，不是历史线路。数量仅为空间背景，不代表 Muni 涉事或个人风险。最新年份可能不完整。
